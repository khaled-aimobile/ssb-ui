<template>
  <footer class="footer">
    <b-container fluid>
      <b-row>
        <div class="col-sm-6">{{ new Date().getFullYear() - 1 }} - {{ new Date().getFullYear() }} © Skote.</div>
        <div class="col-sm-6">
          <div class="text-sm-end d-none d-sm-block">Design & Develop by Themesbrand</div>
        </div>
      </b-row>
    </b-container>
  </footer>
  <!-- end footer -->
</template>
