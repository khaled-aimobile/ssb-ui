<script>
export default {
    components: {},
};
</script>

<template>
<div>
    <div class="account-pages my-5 pt-5">
        <b-container>
            <slot />
        </b-container>
    </div>
</div>
</template>
